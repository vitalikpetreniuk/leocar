import Swiper from '../../../../../../plugins/brainwave/assembly/node_modules/swiper';
import Navigation from '../../../../../../plugins/brainwave/assembly/node_modules/swiper/modules/navigation.min.mjs';

const ourTeamSwiper = document.querySelectorAll('.swiper');
if (ourTeamSwiper.length > 0) {
    ourTeamSwiper.forEach((element, index) => {
        const swiperSlider = new Swiper(element, {
            modules: [Navigation],
            navigation: {
                nextEl: `.our-team .swiper-button-next`,
                prevEl: `.our-team .swiper-button-prev`,
            },
            breakpoints: {
                320: {
                    slidesPerView: 1,
                    spaceBetween: 20
                },
                560: {
                    slidesPerView: 2,
                    spaceBetween: 30
                },
                991: {
                    slidesPerView: 3,
                    spaceBetween: 40
                }
            }
        });
    })
}